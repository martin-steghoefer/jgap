package bestaspirant;
import robocode.*;
import java.awt.Color;
public class Aspirant_winner extends Robot
{
         public void run() {
               setColors(Color.red,Color.blue,Color.green);
                while(true)
               {
turnGunLeft (((135.0d)*((135.0d)*((135.0d)*((90.0d)/(90.0d))))));
turnGunLeft (((135.0d)*((135.0d)*((135.0d)*((90.0d)/(90.0d))))));
turnGunLeft (((135.0d)*((90.0d)/(90.0d))));
               }
         }
         public void onScannedRobot(ScannedRobotEvent e) {
fire (getHeading());
fire (getHeading());
if(((getHeading()/e.getDistance())>(getHeading()/e.getDistance()))) {ahead (getHeading());} else {fire ((108.9639892578125d));};
         }
         public void onHitByBullet(HitByBulletEvent e) {
turnLeft (((2.6682870388031006d)-(((2.6682870388031006d)-(getHeading()*(getHeading()-getHeading())))*(getHeading()-getHeading()))));
turnLeft (((2.6682870388031006d)-(getHeading()*(getHeading()-getHeading()))));
turnGunRight ((getHeading()-getHeading()));
         }
         public void onHitWall(HitWallEvent e) {
ahead (getHeading());
turnRight ((180.0d));
turnRight ((180.0d));
         }
         public void onHitRobot(HitRobotEvent e) {
fire (getHeading());
fire (getHeading());
fire (getHeading());
         }
}
