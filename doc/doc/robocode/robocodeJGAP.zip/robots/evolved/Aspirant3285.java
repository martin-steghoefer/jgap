package evolved;
import robocode.*;
import java.awt.Color;
public class Aspirant3285 extends Robot
{
         public void run() {
               setColors(Color.red,Color.blue,Color.green);
                while(true)
               {
turnLeft (getHeading());
turnLeft (getHeading());
turnLeft (getHeading());
               }
         }
         public void onScannedRobot(ScannedRobotEvent e) {
turnRight ((-45.0d));
turnGunRight ((e.getBearing()*(-45.0d)));
turnGunRight ((e.getBearing()*(-45.0d)));
         }
         public void onHitByBullet(HitByBulletEvent e) {
turnRight (e.getBearing());
fire (((-90.0d)*(-90.0d)));
ahead (getHeading());
         }
         public void onHitWall(HitWallEvent e) {
turnGunRight ((-45.0d));
turnGunLeft (((135.0d)+getHeading()));
ahead (((135.0d)+getHeading()));
         }
         public void onHitRobot(HitRobotEvent e) {
turnGunLeft (((e.getBearing()+e.getBearing())+e.getBearing()));
fire (e.getEnergy());
turnRight ((e.getBearing()+e.getBearing()));
         }
}
